# Type casting trials
a="10"
b="30"
a=int(a)
b=int(b)
c=a+b
print(a)
print(a,type(a))


x=input("Enter the number you want to multiply:")
x=int(x)
print(x,type(x))
y=10
z=x*y
print(z,type(z))


a=input("Enter your name:")
a=str(a)
b=input("Enter your college id no:")
b=float(b)
c=input("Enter your roll no:")
c=int(c)
d=input("Are you above 18:True")
d=bool(d)

print(a,type(a))
print(b,type(b))
print(c,type(c))
print(d,type(d))
